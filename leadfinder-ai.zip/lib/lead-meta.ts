export const LEAD_STATUSES = ["new", "contacted", "qualified", "proposal", "won", "lost"] as const
export type LeadStatus = (typeof LEAD_STATUSES)[number]

type StatusMeta = {
  label: string
  // Tailwind classes for the badge (bg + text + border), themed via tokens where possible
  className: string
  dot: string
}

export const STATUS_META: Record<LeadStatus, StatusMeta> = {
  new: {
    label: "New",
    className: "bg-secondary text-secondary-foreground border-border",
    dot: "bg-muted-foreground",
  },
  contacted: {
    label: "Contacted",
    className: "bg-chart-3/15 text-chart-3 border-chart-3/30",
    dot: "bg-chart-3",
  },
  qualified: {
    label: "Qualified",
    className: "bg-primary/15 text-primary border-primary/30",
    dot: "bg-primary",
  },
  proposal: {
    label: "Proposal",
    className: "bg-chart-2/15 text-chart-2 border-chart-2/30",
    dot: "bg-chart-2",
  },
  won: {
    label: "Won",
    className: "bg-chart-2/20 text-chart-2 border-chart-2/40",
    dot: "bg-chart-2",
  },
  lost: {
    label: "Lost",
    className: "bg-destructive/15 text-destructive border-destructive/30",
    dot: "bg-destructive",
  },
}

export function statusMeta(status: string): StatusMeta {
  return STATUS_META[(status as LeadStatus) in STATUS_META ? (status as LeadStatus) : "new"]
}

export function scoreTone(score: number): string {
  if (score >= 75) return "text-chart-2"
  if (score >= 50) return "text-chart-3"
  if (score >= 25) return "text-muted-foreground"
  return "text-muted-foreground"
}

export function initials(name: string): string {
  return name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((n) => n[0]?.toUpperCase() ?? "")
    .join("")
}
