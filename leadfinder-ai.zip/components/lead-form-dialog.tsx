"use client"

import { useState, useTransition } from "react"
import { toast } from "sonner"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { LEAD_STATUSES, STATUS_META } from "@/lib/lead-meta"
import { createLead, updateLead } from "@/app/actions/leads"
import type { Lead } from "@/lib/db/schema"

type LeadFormDialogProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  lead?: Lead | null
}

const EMPTY = {
  name: "",
  company: "",
  title: "",
  email: "",
  phone: "",
  website: "",
  industry: "",
  location: "",
  source: "",
  status: "new",
  score: 0,
  notes: "",
}

export function LeadFormDialog({ open, onOpenChange, lead }: LeadFormDialogProps) {
  const isEdit = Boolean(lead)
  const [isPending, startTransition] = useTransition()
  const [form, setForm] = useState(() => hydrate(lead))

  // Re-sync form when a different lead is opened for editing.
  const [lastLeadId, setLastLeadId] = useState<number | null>(lead?.id ?? null)
  if ((lead?.id ?? null) !== lastLeadId) {
    setLastLeadId(lead?.id ?? null)
    setForm(hydrate(lead))
  }

  function set<K extends keyof typeof EMPTY>(key: K, value: (typeof EMPTY)[K]) {
    setForm((f) => ({ ...f, [key]: value }))
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!form.name.trim() || !form.company.trim()) {
      toast.error("Name and company are required")
      return
    }

    startTransition(async () => {
      try {
        if (isEdit && lead) {
          await updateLead(lead.id, form)
          toast.success("Lead updated")
        } else {
          await createLead(form)
          toast.success("Lead added")
        }
        onOpenChange(false)
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Something went wrong")
      }
    })
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90svh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit lead" : "Add a new lead"}</DialogTitle>
          <DialogDescription>
            {isEdit
              ? "Update the details for this lead."
              : "Capture a new prospect and start tracking them through your pipeline."}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="grid gap-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Name" required>
              <Input
                value={form.name}
                onChange={(e) => set("name", e.target.value)}
                placeholder="Jane Doe"
                required
              />
            </Field>
            <Field label="Company" required>
              <Input
                value={form.company}
                onChange={(e) => set("company", e.target.value)}
                placeholder="Acme Inc"
                required
              />
            </Field>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Title">
              <Input
                value={form.title}
                onChange={(e) => set("title", e.target.value)}
                placeholder="Head of Growth"
              />
            </Field>
            <Field label="Industry">
              <Input
                value={form.industry}
                onChange={(e) => set("industry", e.target.value)}
                placeholder="SaaS"
              />
            </Field>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Email">
              <Input
                type="email"
                value={form.email}
                onChange={(e) => set("email", e.target.value)}
                placeholder="jane@acme.com"
              />
            </Field>
            <Field label="Phone">
              <Input
                value={form.phone}
                onChange={(e) => set("phone", e.target.value)}
                placeholder="+1 555 000 0000"
              />
            </Field>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label="Website">
              <Input
                value={form.website}
                onChange={(e) => set("website", e.target.value)}
                placeholder="acme.com"
              />
            </Field>
            <Field label="Location">
              <Input
                value={form.location}
                onChange={(e) => set("location", e.target.value)}
                placeholder="New York, NY"
              />
            </Field>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Field label="Status">
              <Select value={form.status} onValueChange={(v) => set("status", v ?? "new")}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LEAD_STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {STATUS_META[s].label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Source">
              <Input
                value={form.source}
                onChange={(e) => set("source", e.target.value)}
                placeholder="Referral"
              />
            </Field>
            <Field label={`Score (${form.score})`}>
              <Input
                type="number"
                min={0}
                max={100}
                value={form.score}
                onChange={(e) => set("score", Number(e.target.value))}
              />
            </Field>
          </div>

          <Field label="Notes">
            <Textarea
              value={form.notes}
              onChange={(e) => set("notes", e.target.value)}
              placeholder="Context, next steps, anything useful..."
              rows={3}
            />
          </Field>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isPending}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isPending}>
              {isPending ? "Saving..." : isEdit ? "Save changes" : "Add lead"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

function Field({
  label,
  required,
  children,
}: {
  label: string
  required?: boolean
  children: React.ReactNode
}) {
  return (
    <div className="grid gap-2">
      <Label className="text-xs font-medium text-muted-foreground">
        {label}
        {required && <span className="text-destructive"> *</span>}
      </Label>
      {children}
    </div>
  )
}

function hydrate(lead?: Lead | null) {
  if (!lead) return { ...EMPTY }
  return {
    name: lead.name ?? "",
    company: lead.company ?? "",
    title: lead.title ?? "",
    email: lead.email ?? "",
    phone: lead.phone ?? "",
    website: lead.website ?? "",
    industry: lead.industry ?? "",
    location: lead.location ?? "",
    source: lead.source ?? "",
    status: lead.status ?? "new",
    score: lead.score ?? 0,
    notes: lead.notes ?? "",
  }
}
