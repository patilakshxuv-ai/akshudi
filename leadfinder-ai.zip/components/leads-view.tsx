"use client"

import { useMemo, useState } from "react"
import { Plus, Search, Users, MoreHorizontal, Pencil, Trash2, Sparkles } from "lucide-react"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { LeadFormDialog } from "@/components/lead-form-dialog"
import { LeadDetailDialog } from "@/components/lead-detail-dialog"
import { LEAD_STATUSES, STATUS_META, initials, scoreTone } from "@/lib/lead-meta"
import { deleteLead, seedDemoLeads } from "@/app/actions/leads"
import type { Lead } from "@/lib/db/schema"

const FILTERS = ["all", ...LEAD_STATUSES] as const

export function LeadsView({ leads }: { leads: Lead[] }) {
  const [search, setSearch] = useState("")
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("all")
  const [formOpen, setFormOpen] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)
  const [editingLead, setEditingLead] = useState<Lead | null>(null)
  const [activeLead, setActiveLead] = useState<Lead | null>(null)
  const [seeding, setSeeding] = useState(false)

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase()
    return leads.filter((lead) => {
      const matchesFilter = filter === "all" || lead.status === filter
      if (!matchesFilter) return false
      if (!term) return true
      return [lead.name, lead.company, lead.email, lead.industry, lead.title]
        .filter(Boolean)
        .some((v) => v!.toLowerCase().includes(term))
    })
  }, [leads, search, filter])

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: leads.length }
    for (const s of LEAD_STATUSES) c[s] = 0
    for (const lead of leads) c[lead.status] = (c[lead.status] ?? 0) + 1
    return c
  }, [leads])

  function openAdd() {
    setEditingLead(null)
    setFormOpen(true)
  }

  function openEdit(lead: Lead) {
    setEditingLead(lead)
    setFormOpen(true)
  }

  function openDetail(lead: Lead) {
    setActiveLead(lead)
    setDetailOpen(true)
  }

  async function handleQuickDelete(lead: Lead) {
    try {
      await deleteLead(lead.id)
      toast.success("Lead deleted")
    } catch {
      toast.error("Could not delete lead")
    }
  }

  async function handleSeed() {
    setSeeding(true)
    try {
      await seedDemoLeads()
      toast.success("Sample leads added")
    } catch {
      toast.error("Could not add sample leads")
    } finally {
      setSeeding(false)
    }
  }

  return (
    <div className="flex flex-col gap-4">
      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" aria-hidden />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, company, email, industry..."
            className="pl-9"
            aria-label="Search leads"
          />
        </div>
        <Button onClick={openAdd} className="shrink-0">
          <Plus className="h-4 w-4" />
          Add lead
        </Button>
      </div>

      {/* Status filter chips */}
      <div className="flex flex-wrap gap-2">
        {FILTERS.map((f) => {
          const active = filter === f
          const label = f === "all" ? "All" : STATUS_META[f].label
          return (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-sm transition-colors ${
                active
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card text-muted-foreground hover:text-foreground hover:border-muted-foreground/40"
              }`}
            >
              {label}
              <span
                className={`tabular-nums text-xs ${
                  active ? "text-primary-foreground/80" : "text-muted-foreground/70"
                }`}
              >
                {counts[f] ?? 0}
              </span>
            </button>
          )
        })}
      </div>

      {/* Table / empty state */}
      <Card className="overflow-hidden py-0">
        {filtered.length === 0 ? (
          <EmptyState
            hasLeads={leads.length > 0}
            onAdd={openAdd}
            onSeed={handleSeed}
            seeding={seeding}
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="min-w-[220px]">Lead</TableHead>
                  <TableHead className="hidden md:table-cell">Industry</TableHead>
                  <TableHead className="hidden lg:table-cell">Source</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Score</TableHead>
                  <TableHead className="w-10" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((lead) => {
                  const meta = STATUS_META[lead.status as keyof typeof STATUS_META] ?? STATUS_META.new
                  return (
                    <TableRow
                      key={lead.id}
                      className="cursor-pointer"
                      onClick={() => openDetail(lead)}
                    >
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-9 w-9">
                            <AvatarFallback className="bg-primary/15 text-primary text-xs font-semibold">
                              {initials(lead.name)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="min-w-0">
                            <div className="font-medium text-foreground truncate">{lead.name}</div>
                            <div className="text-sm text-muted-foreground truncate">
                              {lead.title ? `${lead.title} · ` : ""}
                              {lead.company}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell text-muted-foreground">
                        {lead.industry || "—"}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell text-muted-foreground">
                        {lead.source || "—"}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={`gap-1.5 ${meta.className}`}>
                          <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
                          {meta.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <span className={`font-semibold tabular-nums ${scoreTone(lead.score)}`}>
                          {lead.score}
                        </span>
                      </TableCell>
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        <DropdownMenu>
                          <DropdownMenuTrigger
                            render={
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Open actions</span>
                              </Button>
                            }
                          />
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEdit(lead)}>
                              <Pencil className="h-4 w-4" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-destructive focus:text-destructive"
                              onClick={() => handleQuickDelete(lead)}
                            >
                              <Trash2 className="h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>

      <LeadFormDialog open={formOpen} onOpenChange={setFormOpen} lead={editingLead} />
      <LeadDetailDialog
        lead={activeLead}
        open={detailOpen}
        onOpenChange={setDetailOpen}
        onEdit={openEdit}
      />
    </div>
  )
}

function EmptyState({
  hasLeads,
  onAdd,
  onSeed,
  seeding,
}: {
  hasLeads: boolean
  onAdd: () => void
  onSeed: () => void
  seeding: boolean
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-4 px-6 py-16 text-center">
      <span className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
        <Users className="h-6 w-6" aria-hidden />
      </span>
      <div className="space-y-1">
        <h3 className="text-lg font-semibold text-foreground">
          {hasLeads ? "No leads match your filters" : "No leads yet"}
        </h3>
        <p className="text-sm text-muted-foreground max-w-sm text-pretty">
          {hasLeads
            ? "Try adjusting your search or status filter to find what you're looking for."
            : "Add your first lead to start tracking prospects through your pipeline, or load some sample data to explore."}
        </p>
      </div>
      <div className="flex flex-wrap items-center justify-center gap-2">
        <Button onClick={onAdd}>
          <Plus className="h-4 w-4" />
          Add lead
        </Button>
        {!hasLeads && (
          <Button variant="outline" onClick={onSeed} disabled={seeding}>
            <Sparkles className="h-4 w-4" />
            {seeding ? "Loading..." : "Load sample leads"}
          </Button>
        )}
      </div>
    </div>
  )
}
