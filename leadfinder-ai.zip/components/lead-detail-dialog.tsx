"use client"

import { useTransition } from "react"
import { toast } from "sonner"
import {
  Building2,
  Mail,
  Phone,
  Globe,
  MapPin,
  Briefcase,
  Radio,
  Pencil,
  Trash2,
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { LEAD_STATUSES, STATUS_META, initials, scoreTone } from "@/lib/lead-meta"
import { deleteLead, updateLeadStatus } from "@/app/actions/leads"
import type { Lead } from "@/lib/db/schema"

type Props = {
  lead: Lead | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onEdit: (lead: Lead) => void
}

export function LeadDetailDialog({ lead, open, onOpenChange, onEdit }: Props) {
  const [isPending, startTransition] = useTransition()

  if (!lead) return null

  function handleStatusChange(status: string | null) {
    if (!lead || !status) return
    startTransition(async () => {
      try {
        await updateLeadStatus(lead.id, status)
        toast.success("Status updated")
      } catch {
        toast.error("Could not update status")
      }
    })
  }

  function handleDelete() {
    if (!lead) return
    startTransition(async () => {
      try {
        await deleteLead(lead.id)
        toast.success("Lead deleted")
        onOpenChange(false)
      } catch {
        toast.error("Could not delete lead")
      }
    })
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90svh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="sr-only">Lead details for {lead.name}</DialogTitle>
        </DialogHeader>

        <div className="flex items-start gap-4">
          <Avatar className="h-14 w-14">
            <AvatarFallback className="bg-primary/15 text-primary text-base font-semibold">
              {initials(lead.name)}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <h2 className="text-xl font-semibold text-foreground text-balance">{lead.name}</h2>
            <p className="text-sm text-muted-foreground">
              {lead.title ? `${lead.title} · ` : ""}
              {lead.company}
            </p>
          </div>
          <div className="text-right">
            <div className={`text-2xl font-semibold tabular-nums ${scoreTone(lead.score)}`}>
              {lead.score}
            </div>
            <div className="text-xs text-muted-foreground">Lead score</div>
          </div>
        </div>

        <div className="mt-2 grid gap-2">
          <span className="text-xs font-medium text-muted-foreground">Pipeline status</span>
          <Select value={lead.status} onValueChange={handleStatusChange} disabled={isPending}>
            <SelectTrigger className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {LEAD_STATUSES.map((s) => (
                <SelectItem key={s} value={s}>
                  <span className="flex items-center gap-2">
                    <span className={`h-2 w-2 rounded-full ${STATUS_META[s].dot}`} />
                    {STATUS_META[s].label}
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Separator className="my-1" />

        <dl className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
          <DetailRow icon={Building2} label="Company" value={lead.company} />
          <DetailRow icon={Briefcase} label="Industry" value={lead.industry} />
          <DetailRow icon={Mail} label="Email" value={lead.email} href={lead.email ? `mailto:${lead.email}` : undefined} />
          <DetailRow icon={Phone} label="Phone" value={lead.phone} href={lead.phone ? `tel:${lead.phone}` : undefined} />
          <DetailRow
            icon={Globe}
            label="Website"
            value={lead.website}
            href={lead.website ? `https://${lead.website.replace(/^https?:\/\//, "")}` : undefined}
          />
          <DetailRow icon={MapPin} label="Location" value={lead.location} />
          <DetailRow icon={Radio} label="Source" value={lead.source} />
        </dl>

        {lead.notes && (
          <>
            <Separator className="my-1" />
            <div className="grid gap-1.5">
              <span className="text-xs font-medium text-muted-foreground">Notes</span>
              <p className="text-sm leading-relaxed text-foreground whitespace-pre-wrap">
                {lead.notes}
              </p>
            </div>
          </>
        )}

        <div className="mt-2 flex items-center justify-between gap-2">
          <Button
            variant="ghost"
            size="sm"
            className="text-destructive hover:text-destructive hover:bg-destructive/10"
            onClick={handleDelete}
            disabled={isPending}
          >
            <Trash2 className="h-4 w-4" />
            Delete
          </Button>
          <Button
            size="sm"
            onClick={() => {
              onOpenChange(false)
              onEdit(lead)
            }}
          >
            <Pencil className="h-4 w-4" />
            Edit lead
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

function DetailRow({
  icon: Icon,
  label,
  value,
  href,
}: {
  icon: React.ElementType
  label: string
  value: string | null
  href?: string
}) {
  return (
    <div className="flex items-start gap-3">
      <Icon className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" aria-hidden />
      <div className="min-w-0">
        <dt className="text-xs text-muted-foreground">{label}</dt>
        <dd className="text-sm text-foreground truncate">
          {value ? (
            href ? (
              <a href={href} className="hover:text-primary hover:underline underline-offset-4" target="_blank" rel="noreferrer">
                {value}
              </a>
            ) : (
              value
            )
          ) : (
            <span className="text-muted-foreground/60">—</span>
          )}
        </dd>
      </div>
    </div>
  )
}
