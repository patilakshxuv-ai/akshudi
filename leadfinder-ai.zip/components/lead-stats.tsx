import { Users, Target, Trophy, TrendingUp } from "lucide-react"
import { Card } from "@/components/ui/card"

type Stats = {
  total: number
  byStatus: Record<string, number>
  won: number
  winRate: number
}

export function LeadStats({ stats }: { stats: Stats }) {
  const qualified =
    (stats.byStatus["qualified"] ?? 0) + (stats.byStatus["proposal"] ?? 0)

  const items = [
    {
      label: "Total leads",
      value: stats.total,
      icon: Users,
      hint: `${stats.byStatus["new"] ?? 0} new`,
      tone: "text-primary bg-primary/10",
    },
    {
      label: "In pipeline",
      value: qualified,
      icon: Target,
      hint: "qualified + proposal",
      tone: "text-chart-3 bg-chart-3/10",
    },
    {
      label: "Won",
      value: stats.won,
      icon: Trophy,
      hint: "closed deals",
      tone: "text-chart-2 bg-chart-2/10",
    },
    {
      label: "Win rate",
      value: `${stats.winRate}%`,
      icon: TrendingUp,
      hint: "of closed leads",
      tone: "text-chart-2 bg-chart-2/10",
    },
  ]

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {items.map((item) => (
        <Card key={item.label} className="p-4 sm:p-5">
          <div className="flex items-center justify-between gap-2">
            <span className="text-sm text-muted-foreground">{item.label}</span>
            <span className={`flex h-8 w-8 items-center justify-center rounded-md ${item.tone}`}>
              <item.icon className="h-4 w-4" aria-hidden />
            </span>
          </div>
          <div className="mt-3 text-2xl font-semibold tabular-nums text-foreground">
            {item.value}
          </div>
          <p className="mt-1 text-xs text-muted-foreground">{item.hint}</p>
        </Card>
      ))}
    </div>
  )
}
